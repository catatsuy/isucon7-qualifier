package t::lib::ClassType_Foo;
use Mouse;
has 'foo' => ( is => 'rw' );
1;
