package Variable::Magic::TestDestroyRequired;

use Variable::Magic;

my $tag = Variable::Magic::wizard();

1;
